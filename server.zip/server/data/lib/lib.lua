-- Core API functions implemented in Lua
dofile('data/lib/core/core.lua')
dofile('data/lib/lamp_states.lua')

-- Compatibility library for our old Lua API
dofile('data/lib/compat/compat.lua')

-- Boost Creature
dofile('data/lib/custom/boostCreature.lua')

dofile('data/lib/modalwindow.lua')

-- Online Time System
dofile('data/lib/custom/onlineTime.lua')

--BountyHunterSystem
dofile('data/lib/custom/bountyhunter.lua')