function onStartup()
    loadLampStates()
end