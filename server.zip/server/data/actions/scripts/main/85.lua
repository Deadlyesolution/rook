function onUse(player, item, fromPosition, target, toPosition)
	player:teleportTo({x = 33452, y = 31791, z = 8})
	return true
end


