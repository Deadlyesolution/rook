function onUse(player, item, fromPosition, target, toPosition)
	Game.createItem(2992, 1, fromPosition)
	return true
end
