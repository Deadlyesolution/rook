function onUse(player, item, fromPosition, target, toPosition)
	return doDestroyItem(target)
end
