function onUse(player, item, fromPosition, target, toPosition)
	player:sendCancelMessage("Hug me ^^")
	return true
end
