local requirements = {
    {5208, 1}, -- Nose Ring
	{5207, 1} -- Behemoth Claw
}

local addons = {184,183}

function onUse(player, item, fromPos, target, toPos, isHotkey)
    if player:hasOutfit(addons[1], 3) and player:hasOutfit(addons[2], 3) then
        player:sendCancelMessage("You already have this outfit.")
        return true
    end

    for _, req in pairs(requirements) do
        if player:getItemCount(req[1]) < req[2] then
            player:sendCancelMessage("Sorry, you need 1 nose ring and behemoth claw.")
            return true
        end
    end

    for _, req in pairs(requirements) do
        player:removeItem(req[1], req[2])
    end

    player:addOutfitAddon(addons[1], 2)
    player:addOutfitAddon(addons[2], 2)
    player:sendTextMessage(MESSAGE_INFO_DESCR, "You received the Assassin addon.")
    item:remove(1)
    return true
end