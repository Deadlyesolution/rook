function onKill(player, target)
    return onBountyHunterKill(player, target)
end