local config = {
    ["lizard sentinel"] = {count = 500, storage = 1023, start = 1, plural = "lizards"},
	["lizard snakecharmer"] = {count = 500, storage = 1023, start = 1, plural = "lizards"},
	["lizard templar"] = {count = 500, storage = 1023, start = 1, plural = "lizards"},

    ["dwarf"] = {count = 400, storage = 1002, start = 1, plural = "dwarves"},
    ["dwarf soldier"] = {count = 400, storage = 1002, start = 1, plural = "dwarves"},

    ["ghoul"] = {count = 200, storage = 1003, start = 1, plural = "ghouls"},
    ["goblin"] = {count = 150, storage = 1004, start = 1, plural = "goblins"},
    ["larva"] = {count = 200, storage = 1005, start = 1, plural = "larva"},

    ["minotaur"] = {count = 400, storage = 1006, start = 1, plural = "minotaurs all kind"},
    ["minotaur guard"] = {count = 400, storage = 1006, start = 1, plural = "minotaurs all kind"},
    ["minotaur mage"] = {count = 400, storage = 1006, start = 1, plural = "minotaurs all kind"},
    ["minotaur archer"] = {count = 400, storage = 1006, start = 1, plural = "minotaurs all kind"},

    ["rotworm"] = {count = 200, storage = 1007, start = 1, plural = "rotworms"},

    ["orc"] = {count = 400, storage = 1008, start = 1, plural = "orcs"},
    --["orc shaman"] = {count = 400, storage = 1008, start = 1, plural = "orcs all kind"},
    --["orc rider"] = {count = 400, storage = 1008, start = 1, plural = "orcs all kind"},
    --["orc warlord"] = {count = 400, storage = 1008, start = 1, plural = "orcs all kind"},
	["orc spearman"] = {count = 400, storage = 1008, start = 1, plural = "orcs"},
    --["orc leader"] = {count = 400, storage = 1008, start = 1, plural = "orcs all kind"},
    --["orc berserker"] = {count = 400, storage = 1008, start = 1, plural = "orcs all kind"},
    ["orc warrior"] = {count = 400, storage = 1008, start = 1, plural = "orcs"},

    --["panda"] = {count = 150, storage = 1009, start = 1, plural = "pandas"},

    ["scarab"] = {count = 150, storage = 1010, start = 1, plural = "scarabs"},


    ["tarantula"] = {count = 100, storage = 1011, start = 1, plural = "tarantulas"},

    ["troll"] = {count = 100, storage = 1012, start = 1, plural = "trolls"},

    ["ancient scarab"] = {count = 200, storage = 1013, start = 1, plural = "ancient scarabs"},

    ["kongra"] = {count = 250, storage = 1014, start = 1, plural = "apes"},
    ["merlkin"] = {count = 250, storage = 1014, start = 1, plural = "apes"},
    ["sibang"] = {count = 250, storage = 1014, start = 1, plural = "apes"},

    ["black knight"] = {count = 350, storage = 1015, start = 1, plural = "black knight"},

    ["cyclops"] = {count = 150, storage = 1016, start = 1, plural = "cyclopses"},

    ["demon skeleton"] = {count = 100, storage = 1017, start = 1, plural = "demon skeleton"},

    ["dragon"] = {count = 300, storage = 1018, start = 1, plural = "dragons"},

    ["dwarf guard"] = {count = 400, storage = 1019, start = 1, plural = "dwarf guards"},

    ["fire elemental"] = {count = 500, storage = 1020, start = 1, plural = "fire elementals"},

    ["giant spider"] = {count = 200, storage = 1021, start = 1, plural = "giant spiders"},

    ["hero"] = {count = 250, storage = 1022, start = 1, plural = "heroes"},

    ["hunter"] = {count = 150, storage = 1001, start = 1, plural = "hunters"},

    ["necromancer"] = {count = 200, storage = 1024, start = 1, plural = "necromancers"},

    ["terror bird"] = {count = 100, storage = 1025, start = 1, plural = "terror birds"},

    ["vampire"] = {count = 200, storage = 1026, start = 1, plural = "vampires"},

    ["behemoth"] = {count = 150, storage = 1027, start = 1, plural = "behemoth"},

    ["dragon lord"] = {count = 200, storage = 1028, start = 1, plural = "dragon lords"},

    ["demon"] = {count = 100, storage = 1029, start = 1, plural = "demons"},

    ["hydra"] = {count = 200, storage = 1030, start = 1, plural = "hydras"},

    ["serpent spawn"] = {count = 250, storage = 1031, start = 1, plural = "serpent spawns"},

    ["warlock"] = {count = 200, storage = 1032, start = 1, plural = "warlocks"},

    ["swamp troll"] = {count = 100, storage = 1033, start = 1, plural = "swamp trolls"},
    ["bug"] = {count = 100, storage = 1034, start = 1, plural = "bugs"},
    ["hyaena"] = {count = 100, storage = 1035, start = 1, plural = "hyaenas"},
    ["frost troll"] = {count = 100, storage = 1036, start = 1, plural = "frost troll"},
    ["wasp"] = {count = 150, storage = 1037, start = 1, plural = "wasps"},
    ["stone golem"] = {count = 150, storage = 1038, start = 1, plural = "stone golem"},
    ["poison spider"] = {count = 100, storage = 1039, start = 1, plural = "poison spider"},
    ["witch"] = {count = 100, storage = 1040, start = 1, plural = "witch"},
    ["skeleton"] = {count = 150, storage = 1041, start = 1, plural = "skeleton"},
	
    ["elf"] = {count = 500, storage = 1042, start = 1, plural = "elfs all kind"},
	["elf scout"] = {count = 500, storage = 1042, start = 1, plural = "elfs all kind"},
	["elf arcanist"] = {count = 500, storage = 1042, start = 1, plural = "elfs all kind"},
	
    ["ghost"] = {count = 150, storage = 1043, start = 1, plural = "ghost"},
    ["scorpion"] = {count = 100, storage = 1044, start = 1, plural = "scorpion"},
    ["cave rat"] = {count = 100, storage = 1045, start = 1, plural = "cave rats"},
    ["snake"] = {count = 100, storage = 1046, start = 1, plural = "snakes"},
    ["lion"] = {count = 50, storage = 1047, start = 1, plural = "lions"},
    ["amazon"] = {count = 100, storage = 1048, start = 1, plural = "amazon"},
    ["valkyrie"] = {count = 100, storage = 1049, start = 1, plural = "valkyrie"},
    --["orc spearman"] = {count = 400, storage = 1050, start = 1, plural = "orc spearman"},
    ["beholder"] = {count = 100, storage = 1051, start = 1, plural = "beholders"},
    ["crypt shambler"] = {count = 200, storage = 1052, start = 1, plural = "crypt shamblers"},
    ["mummy"] = {count = 200, storage = 1053, start = 1, plural = "mummies"},
    ["rat"] = {count = 50, storage = 1054, start = 1, plural = "rats"},
	["dwarf geomancer"] = {count = 500, storage = 1055, start = 1, plural = "dwarf geomancers"},
	["cyclops smith"] = {count = 200, storage = 1056, start = 1, plural = "cyclops smiths"},
	["cyclops drone"] = {count = 250, storage = 1057, start = 1, plural = "cyclops drone"},
	["nightmare"] = {count = 200, storage = 1058, start = 1, plural = "nightmares"},
}

local function getKillers(creature, party)
    local killers = {}
    local timeNow = os.mtime()
    local inFightTicks = configManager.getNumber(configKeys.PZ_LOCKED)
    for uid, cb in pairs(creature:getDamageMap()) do
        local attacker = Player(uid)
        if (attacker and attacker ~= creature and timeNow - cb.ticks <= inFightTicks) then
            local p = attacker
            if p and p == party then
                killers[#killers +1] = attacker
            end
        end
    end
    return killers
end

function onKill(player, target)
    local monster = config[target:getName():lower()]
    if not monster or target:getMaster() then
        return true
    end
    local killers = getKillers(target, player)
    for k, member in pairs(killers) do
        local storageValue = member:getStorageValue(monster.storage)
        if storageValue >= monster.start then
            if storageValue >= monster.count then
                member:sendTextMessage(MESSAGE_STATUS_CONSOLE_ORANGE, "You have already killed " .. monster.count .. " " .. monster.plural .. ". Report back to Tusker.")
            else
                member:sendTextMessage(MESSAGE_STATUS_CONSOLE_ORANGE, "You have killed [" .. storageValue .. "/" .. monster.count .. "] " .. monster.plural .. ".")
            end
            member:setStorageValue(monster.storage, storageValue + 1)
        end
    end
    return true
end