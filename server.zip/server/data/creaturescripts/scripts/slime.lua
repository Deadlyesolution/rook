function onDeath(creature, corpse, killer, mostDamage, unjustified, mostDamage_unjustified)
     creature:getPosition():sendMagicEffect(9)
      return true
end